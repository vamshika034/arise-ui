import streamlit as st
import cv2
import numpy as np
from PIL import Image
from src.detector import detect_candidate_regions, draw_regions
from src.xml_generator import generate_android_xml

st.set_page_config(page_title="ARISE-UI Baseline", layout="wide")
st.title("ARISE-UI: Android Screenshot Reconstruction")
st.caption("Starter baseline • OpenCV region proposals • illustrative Android XML")

st.warning(
    "This is a heuristic prototype, not a trained semantic UI detector. "
    "Candidate regions are not guaranteed to be buttons, text fields, or images."
)

uploaded = st.file_uploader("Upload an Android UI screenshot", type=["png", "jpg", "jpeg"])
if uploaded:
    pil_img = Image.open(uploaded).convert("RGB")
    image = np.array(pil_img)
    h, w = image.shape[:2]
    st.write(f"Screenshot dimensions: **{w} × {h} px**")

    min_area = st.slider("Minimum candidate region area (pixels)", 100, 10000, 700, 100)
    regions = detect_candidate_regions(image, min_area=min_area)
    annotated = draw_regions(image, regions)

    left, right = st.columns(2)
    with left:
        st.subheader("Original screenshot")
        st.image(image, use_container_width=True)
    with right:
        st.subheader("Candidate regions")
        st.image(annotated, use_container_width=True)

    st.write(f"Candidate regions found: **{len(regions)}**")
    if regions:
        st.dataframe([
            {"id": i + 1, "x": r["x"], "y": r["y"],
             "width": r["width"], "height": r["height"],
             "area": r["width"] * r["height"]}
            for i, r in enumerate(regions)
        ], use_container_width=True)

    xml = generate_android_xml(regions, w, h)
    st.subheader("Illustrative Android XML")
    st.code(xml, language="xml")
    st.download_button(
        "Download generated XML",
        data=xml,
        file_name="activity_generated.xml",
        mime="application/xml"
    )

    st.info(
        "Next improvement: semantic classification, OCR, parent-child hierarchy, "
        "Android rendering, and feedback-driven correction. This first version does not "
        "recover original app logic or guarantee compilable production layouts."
    )
else:
    st.markdown("""
    ### Baseline workflow
    1. Upload a screenshot.
    2. Inspect candidate bounding boxes.
    3. Download the generated XML approximation.
    4. Record failure cases for the research evaluation.
    """)
