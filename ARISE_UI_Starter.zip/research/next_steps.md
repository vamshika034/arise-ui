# Next Steps

1. Run this baseline on 5–10 varied screenshots and save failure examples.
2. Choose a small RICO subset; inspect screenshot and view hierarchy fields.
3. Build a conversion script from hierarchy JSON to labeled bounding boxes.
4. Train/fine-tune a lightweight detector only after labels are verified.
5. Build a reliable XML generator and render output in an Android emulator.
6. Implement constraints (out-of-bounds, overlap, alignment, spacing).
7. Compare one-pass and iterative variants using identical test screens.
8. Update the literature review after reading UI2Code^N and DesignCoder in full.
