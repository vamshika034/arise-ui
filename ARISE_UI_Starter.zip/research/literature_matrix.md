# Initial Literature Matrix — ARISE-UI

This is a starting point, not a completed systematic literature review. Read the full papers and verify scope, datasets, metrics, and limitations before citing them in a final report.

| Work | Scope / contribution | Implication for this project |
|---|---|---|
| REMAUI (2015), Reverse Engineering Mobile Application User Interfaces with REMAUI. DOI: 10.1109/ASE.2015.32 | Computer vision and OCR to infer mobile UI elements and reconstruct interfaces. | Screenshot-to-mobile-UI reconstruction predates current generative models. |
| pix2code (2017), arXiv:1705.07962 | Learns screenshot-to-DSL/code generation. | Include as an early learned screenshot-to-code approach; check evaluation limitations in the paper. |
| ReDraw (2018), DOI: 10.1109/TSE.2018.2844788 | Android UI prototyping through detection, classification, and assembly. | Closest foundational Android-specific predecessor. |
| UIED (2020), DOI: 10.1145/3368089.3417940 | Hybrid GUI element detection using computer vision and deep learning. | Useful reference for the detector stage. |
| Screen Parsing (2021), arXiv:2109.08763 | Predicts UI elements and relationships from screenshots. | Highlights structure and hierarchy beyond boxes. |
| DCGen (2025), DOI: 10.1145/3729364 | Segment-aware website screenshot-to-code generation. | Decomposition can improve generation; web-specific, so transfer to Android must be tested. |
| UI2Code^N (2026), PMLR 306 | Interactive visual optimization with rendered feedback and iterative refinement. | Direct overlap with the broad idea of iterative screenshot-to-code; novelty cannot be claimed at that level. |
| DesignCoder (2026), DOI: 10.1016/j.infsof.2026.108214 | Hierarchy-aware UI code generation and visual self-correction. | Another close overlap; compare its exact task, platform, method, and evaluation. |

## Dataset
RICO: https://www.interactionmining.org/archive/rico
The dataset page reports 66k+ unique UI screens and screenshot/view-hierarchy JSON pairs. Check dataset terms and prepare a reproducible subset. Use app-level train/validation/test splits to reduce leakage.

## Current gap status
**Unverified.** A potentially testable narrower question is whether explicit Android layout constraints and localized component-level correction improve XML validity and visual fidelity versus a one-pass baseline under resource limits. This must be checked against the full text and code of close papers before being described as novel.

## Evaluation plan
- Detection: precision, recall, F1 or mAP, with a documented annotation mapping.
- Geometry: bounding-box IoU.
- Visual output: SSIM and/or pixel error after rendering at the same size and density.
- Structure: XML parse/build/render success, overlap and bounds violations.
- Efficiency: runtime, peak RAM/VRAM, number of correction iterations.
- Split: by application, not randomly by screenshot.
- Ablation: one-pass vs constraints only vs localized correction vs full loop.
- Report actual measured results only; never invent metrics.
