import cv2
import numpy as np

def detect_candidate_regions(rgb_image, min_area=700):
    """Return simple contour-based rectangular region proposals.

    This is intentionally a classical CV baseline, not a trained UI detector.
    """
    image = np.asarray(rgb_image)
    if image.ndim != 3:
        raise ValueError("Expected an RGB image.")
    h, w = image.shape[:2]
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    # Edge + adaptive threshold helps propose both bordered and filled regions.
    edges = cv2.Canny(gray, 50, 150)
    thresh = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV, 31, 7
    )
    mask = cv2.bitwise_or(edges, thresh)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    regions = []
    for c in contours:
        x, y, bw, bh = cv2.boundingRect(c)
        area = bw * bh
        if area < min_area or bw < 12 or bh < 8:
            continue
        # Ignore almost full-screen contours and extreme skinny noise.
        if area > 0.92 * w * h:
            continue
        ratio = bw / max(bh, 1)
        if ratio > 30 or ratio < 0.025:
            continue
        regions.append({"x": int(x), "y": int(y),
                        "width": int(bw), "height": int(bh)})
    # Prefer larger regions first; remove near-duplicate boxes.
    regions.sort(key=lambda r: r["width"] * r["height"], reverse=True)
    kept = []
    for r in regions:
        duplicate = False
        for k in kept:
            ix1, iy1 = max(r["x"], k["x"]), max(r["y"], k["y"])
            ix2 = min(r["x"]+r["width"], k["x"]+k["width"])
            iy2 = min(r["y"]+r["height"], k["y"]+k["height"])
            inter = max(0, ix2-ix1) * max(0, iy2-iy1)
            union = r["width"]*r["height"] + k["width"]*k["height"] - inter
            if union and inter / union > 0.85:
                duplicate = True
                break
        if not duplicate:
            kept.append(r)
    return sorted(kept, key=lambda r: (r["y"], r["x"]))

def draw_regions(rgb_image, regions):
    out = np.asarray(rgb_image).copy()
    for i, r in enumerate(regions):
        x, y, w, h = r["x"], r["y"], r["width"], r["height"]
        cv2.rectangle(out, (x, y), (x+w, y+h), (255, 40, 40), 2)
        cv2.putText(out, str(i+1), (x, max(15, y-4)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 40, 40), 1, cv2.LINE_AA)
    return out
