import xml.etree.ElementTree as ET

def generate_android_xml(regions, image_width, image_height):
    """Generate an illustrative XML skeleton using normalized coordinates.

    Generic View nodes are used because geometry alone cannot reliably identify
    Android widget semantics. This is a prototype artifact, not production XML.
    """
    root = ET.Element("FrameLayout", {
        "xmlns:android": "http://schemas.android.com/apk/res/android",
        "android:layout_width": "match_parent",
        "android:layout_height": "match_parent"
    })
    root.set("tools:context", ".GeneratedActivity")
    root.set("xmlns:tools", "http://schemas.android.com/tools")
    for idx, r in enumerate(regions):
        # Android dp conversion depends on device density; this is only a
        # normalized approximation using a nominal 1 px ~= 1 dp assumption.
        node = ET.SubElement(root, "View", {
            "android:id": f"@+id/candidate_{idx+1}",
            "android:layout_width": f"{max(1, r['width'])}dp",
            "android:layout_height": f"{max(1, r['height'])}dp",
            "android:layout_gravity": "top|start",
            "android:layout_marginStart": f"{max(0, r['x'])}dp",
            "android:layout_marginTop": f"{max(0, r['y'])}dp",
            "android:background": "@android:color/darker_gray",
            "android:contentDescription": f"Unclassified candidate region {idx+1}"
        })
    ET.indent(root, space="    ")
    return '<?xml version="1.0" encoding="utf-8"?>\n' + ET.tostring(root, encoding="unicode")
