import xml.etree.ElementTree as ET
import re

ANDROID_NS = "http://schemas.android.com/apk/res/android"
ET.register_namespace("android", ANDROID_NS)

def _android_attr(name):
    return f"{{{ANDROID_NS}}}{name}"

def _safe_id(text, fallback):
    value = re.sub(r"[^a-zA-Z0-9_]+", "_", text.strip().lower()).strip("_")
    if not value or not value[0].isalpha():
        value = fallback
    return value[:40]

def generate_android_xml(regions, labels, image_width, image_height):
    """Create an illustrative Android XML layout from regions and user labels.

    Coordinates are screenshot pixels treated as dp for this prototype. A real
    implementation must estimate device density/insets and reconstruct hierarchy.
    """
    root = ET.Element("FrameLayout", {
        _android_attr("layout_width"): "match_parent",
        _android_attr("layout_height"): "match_parent"
    })
    root.set("xmlns:tools", "http://schemas.android.com/tools")
    used_ids = set()

    tag_map = {
        "Container": "View",
        "Text": "TextView",
        "Button": "Button",
        "Text input": "EditText",
        "Image/Icon": "ImageView",
        "Checkbox": "CheckBox",
    }
    for idx, (region, label) in enumerate(zip(regions, labels), start=1):
        component = label.get("component", "Container")
        if component == "Ignore":
            continue
        tag = tag_map.get(component, "View")
        visible_text = (label.get("text") or "").strip()
        base = _safe_id(visible_text, f"{component.lower().replace(' ', '_')}_{idx}")
        view_id = base
        suffix = 2
        while view_id in used_ids:
            view_id = f"{base}_{suffix}"
            suffix += 1
        used_ids.add(view_id)

        attrs = {
            _android_attr("id"): f"@+id/{view_id}",
            _android_attr("layout_width"): f"{max(1, int(region['width']))}dp",
            _android_attr("layout_height"): f"{max(1, int(region['height']))}dp",
            _android_attr("layout_gravity"): "top|start",
            _android_attr("layout_marginStart"): f"{max(0, int(region['x']))}dp",
            _android_attr("layout_marginTop"): f"{max(0, int(region['y']))}dp",
        }
        if tag in ("TextView", "Button", "CheckBox") and visible_text:
            attrs[_android_attr("text")] = visible_text
        if tag == "EditText":
            attrs[_android_attr("hint")] = visible_text or "Enter text"
            attrs[_android_attr("inputType")] = "text"
        if tag == "ImageView":
            attrs[_android_attr("contentDescription")] = visible_text or f"Image or icon {idx}"
            attrs[_android_attr("src")] = "@android:drawable/ic_menu_gallery"
        if tag == "View":
            attrs[_android_attr("contentDescription")] = visible_text or f"Container {idx}"
        if tag == "Button":
            attrs[_android_attr("textAllCaps")] = "false"
        ET.SubElement(root, tag, attrs)

    ET.indent(root, space="    ")
    return '<?xml version="1.0" encoding="utf-8"?>\n' + ET.tostring(root, encoding="unicode")
